# FNLLA Brand System v3.0.0

This package contains the selected **FNLLA v3 outline identity** for a blueprint-first developer framework.

## Core assets

- `assets/logo/svg/fnlla-wordmark-outline-v3.svg` - primary custom outline wordmark.
- `assets/logo/svg/fnlla-monogram-outline-v3.svg` - compact Fn mark for icons and favicons.
- `assets/logo/svg/fnlla-recommended-lockup-outline-v3.svg` - recommended lockup for headers.
- `FNLLA-Brand-Guidebook-v3.0.pdf` - complete brand guidebook.

## Typeface recommendation

- Primary product typeface: **Space Grotesk**.
- Code/terminal typeface: **JetBrains Mono**.

No font files are included in this package. Load fonts through your chosen provider or self-host according to the font licenses.

## Primary message

> Build from blueprint.

## Usage

Use the custom outline wordmark and Fn monogram exactly as provided. Do not recreate the wordmark with normal text, do not change the F/n spacing, and do not alter the angular geometry.

