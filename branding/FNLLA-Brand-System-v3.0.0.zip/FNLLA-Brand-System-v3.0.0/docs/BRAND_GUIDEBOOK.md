# FNLLA Brand Guidebook

## Brand definition

FNLLA is a blueprint-first framework for modern web products.

## Logo system

The identity has two official logo assets:

1. **Custom outline wordmark** - `Fnlla`, custom-built, not a font.
2. **Fn monogram** - compact mark for icons, packages, favicons, avatars and small UI.

The recommended website direction uses the custom outline assets on white and light surfaces.

## Do not

- Do not use a filled version as the primary logo.
- Do not recolour the mark outside the approved palette.
- Do not stretch or skew the logo.
- Do not change the F/n spacing.
- Do not recreate the custom wordmark with a standard font.

## Colours

| Token | Hex | Use |
|---|---:|---|
| Blueprint Blue | `#2563EB` | Primary outline, links, CTA |
| Deep Navy | `#0B1220` | Text, headings |
| Blueprint Tint | `#EFF6FF` | Soft panels |
| Light Surface | `#FAFAFA` | Background |
| Border | `#E5E7EB` | Dividers/cards |
| White | `#FFFFFF` | Base background |

## Typography

Use **Space Grotesk** for product UI and editorial sections. Use **JetBrains Mono** for code blocks and terminal snippets.

