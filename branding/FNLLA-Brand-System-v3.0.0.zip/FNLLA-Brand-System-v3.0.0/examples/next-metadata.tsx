import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'FNLLA - Build from blueprint',
  description: 'Blueprint-first framework for modern web products.',
  icons: {
    icon: [
      { url: '/favicon.ico' },
      { url: '/favicon.svg', type: 'image/svg+xml' },
    ],
    apple: [{ url: '/apple-touch-icon.png' }],
  },
  openGraph: {
    title: 'FNLLA',
    description: 'Blueprint-first framework for modern web products.',
    images: [{ url: '/fnlla-open-graph-v3-1200x630.png', width: 1200, height: 630 }],
  },
};
