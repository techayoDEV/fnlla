export const fnllaTheme = {
  colors: {
    fnlla: {
      blue: '#2563EB',
      blueDark: '#1D4ED8',
      blueLight: '#DBEAFE',
      blueTint: '#EFF6FF',
      navy: '#0B1220',
      ink: '#111827',
      text: '#374151',
      muted: '#6B7280',
      border: '#E5E7EB',
      background: '#FAFAFA',
      white: '#FFFFFF',
    },
  },
  fontFamily: {
    brand: ['Space Grotesk', 'Inter', 'system-ui', 'sans-serif'],
    mono: ['JetBrains Mono', 'ui-monospace', 'SFMono-Regular', 'Consolas', 'monospace'],
  },
  borderRadius: {
    fnlla: '14px',
  },
} as const;
